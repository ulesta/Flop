console.log('\'Allo \'Allo!');

$(document).ready(function() {
  	$('#dropdown').mmenu();
});
